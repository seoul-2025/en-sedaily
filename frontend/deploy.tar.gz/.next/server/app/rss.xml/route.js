"use strict";(()=>{var e={};e.id=287,e.ids=[287],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},1355:(e,t,n)=>{n.r(t),n.d(t,{originalPathname:()=>x,patchFetch:()=>$,requestAsyncStorage:()=>m,routeModule:()=>g,serverHooks:()=>y,staticGenerationAsyncStorage:()=>h});var r={};n.r(r),n.d(r,{GET:()=>d});var a=n(9303),i=n(8716),s=n(670),o=n(7070);let l="https://en.sedaily.com",c=process.env.NEXT_PUBLIC_API_URL||"https://7w5nco7xn4.execute-api.us-east-1.amazonaws.com/dev";async function u(e=50){try{let t=await fetch(`${c}/api/search`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:"*",filters:{published_from:"2020-01-01",published_until:"2030-12-31"},page:1,page_size:e,sort_by:"published_at",sort_order:"desc"}),cache:"no-store"});if(!t.ok)return[];return(await t.json()).articles||[]}catch(e){return console.error("Failed to fetch articles for RSS:",e),[]}}function p(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}async function d(){let e=await u(50),t=new Date,n=`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
     xmlns:atom="http://www.w3.org/2005/Atom"
     xmlns:dc="http://purl.org/dc/elements/1.1/"
     xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Seoul Economic Daily - English Edition</title>
    <link>${l}</link>
    <description>Korea's leading economic newspaper. Latest business news, stock market, economy, finance, and technology updates in English.</description>
    <language>en-us</language>
    <lastBuildDate>${t.toUTCString()}</lastBuildDate>
    <atom:link href="${l}/rss.xml" rel="self" type="application/rss+xml" />
    <image>
      <url>${l}/sedaily-logo.png</url>
      <title>Seoul Economic Daily</title>
      <link>${l}</link>
    </image>
${e.map(e=>{var t;let n=function(e){if(!e.slug)return`${l}/article?id=${e.news_id}`;let t=new Date(e.published_at),n=t.getFullYear(),r=String(t.getMonth()+1).padStart(2,"0"),a=String(t.getDate()).padStart(2,"0"),i={경제:"finance",IT_과학:"technology",정치:"politics",사회:"society",문화:"culture",스포츠:"sports",국제:"international"}[e.category]||"news";return`${l}/${i}/${n}/${r}/${a}/${e.slug}`}(e),r=new Date(e.published_at).toUTCString(),a={경제:"Finance",IT_과학:"Technology",정치:"Politics",사회:"Society",문화:"Culture",스포츠:"Sports",국제:"International"}[t=e.category]||t,i=e.meta_description||e.content?.substring(0,300)||e.title;return`    <item>
      <title>${p(e.title)}</title>
      <link>${n}</link>
      <guid isPermaLink="true">${n}</guid>
      <pubDate>${r}</pubDate>
      <category>${a}</category>
      <description>${p(i)}</description>
      ${e.byline?`<dc:creator>${p(e.byline)}</dc:creator>`:""}
    </item>`}).join("\n")}
  </channel>
</rss>`;return new o.NextResponse(n,{status:200,headers:{"Content-Type":"application/rss+xml; charset=utf-8","Cache-Control":"public, max-age=1800, s-maxage=1800"}})}let g=new a.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/rss.xml/route",pathname:"/rss.xml",filename:"route",bundlePath:"app/rss.xml/route"},resolvedPagePath:"D:\\sedaily\\en-sedaily-1st-main\\frontend\\src\\app\\rss.xml\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:m,staticGenerationAsyncStorage:h,serverHooks:y}=g,x="/rss.xml/route";function $(){return(0,s.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:h})}}};var t=require("../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),r=t.X(0,[948,972],()=>n(1355));module.exports=r})();