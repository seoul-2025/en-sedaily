"use strict";(()=>{var e={};e.id=34,e.ids=[34],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4780:(e,t,n)=>{n.r(t),n.d(t,{originalPathname:()=>f,patchFetch:()=>x,requestAsyncStorage:()=>m,routeModule:()=>h,serverHooks:()=>$,staticGenerationAsyncStorage:()=>y});var r={};n.r(r),n.d(r,{GET:()=>d});var a=n(9303),i=n(8716),o=n(670),s=n(7070);let l="https://en.sedaily.com",c=process.env.NEXT_PUBLIC_API_URL||"https://7w5nco7xn4.execute-api.us-east-1.amazonaws.com/dev",u={finance:{korean:"경제",english:"Finance"},technology:{korean:"IT_과학",english:"Technology"},politics:{korean:"정치",english:"Politics"},society:{korean:"사회",english:"Society"},culture:{korean:"문화",english:"Culture"},sports:{korean:"스포츠",english:"Sports"},international:{korean:"국제",english:"International"}};async function p(e,t=50){try{let n=await fetch(`${c}/api/search`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:"*",filters:{category:e,published_from:"2020-01-01",published_until:"2030-12-31"},page:1,page_size:t,sort_by:"published_at",sort_order:"desc"}),cache:"no-store"});if(!n.ok)return[];return(await n.json()).articles||[]}catch(t){return console.error(`Failed to fetch articles for RSS [${e}]:`,t),[]}}function g(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}async function d(e,{params:t}){let n=t.category,r=u[n];if(!r)return new s.NextResponse("Category not found",{status:404});let a=await p(r.korean,50),i=new Date,o=`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
     xmlns:atom="http://www.w3.org/2005/Atom"
     xmlns:dc="http://purl.org/dc/elements/1.1/"
     xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Seoul Economic Daily - ${r.english}</title>
    <link>${l}/${n}</link>
    <description>Latest ${r.english} news from Seoul Economic Daily in English.</description>
    <language>en-us</language>
    <category>${r.english}</category>
    <lastBuildDate>${i.toUTCString()}</lastBuildDate>
    <atom:link href="${l}/rss/${n}.xml" rel="self" type="application/rss+xml" />
    <image>
      <url>${l}/sedaily-logo.png</url>
      <title>Seoul Economic Daily</title>
      <link>${l}</link>
    </image>
${a.map(e=>{let t=function(e,t){if(!e.slug)return`${l}/article?id=${e.news_id}`;let n=new Date(e.published_at),r=n.getFullYear(),a=String(n.getMonth()+1).padStart(2,"0"),i=String(n.getDate()).padStart(2,"0");return`${l}/${t}/${r}/${a}/${i}/${e.slug}`}(e,n),a=new Date(e.published_at).toUTCString(),i=e.meta_description||e.content?.substring(0,300)||e.title;return`    <item>
      <title>${g(e.title)}</title>
      <link>${t}</link>
      <guid isPermaLink="true">${t}</guid>
      <pubDate>${a}</pubDate>
      <category>${r.english}</category>
      <description>${g(i)}</description>
      ${e.byline?`<dc:creator>${g(e.byline)}</dc:creator>`:""}
    </item>`}).join("\n")}
  </channel>
</rss>`;return new s.NextResponse(o,{status:200,headers:{"Content-Type":"application/rss+xml; charset=utf-8","Cache-Control":"public, max-age=1800, s-maxage=1800"}})}let h=new a.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/rss/[category]/route",pathname:"/rss/[category]",filename:"route",bundlePath:"app/rss/[category]/route"},resolvedPagePath:"D:\\sedaily\\en-sedaily-1st-main\\frontend\\src\\app\\rss\\[category]\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:m,staticGenerationAsyncStorage:y,serverHooks:$}=h,f="/rss/[category]/route";function x(){return(0,o.patchFetch)({serverHooks:$,staticGenerationAsyncStorage:y})}}};var t=require("../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),r=t.X(0,[948,972],()=>n(4780));module.exports=r})();